exports.handleRedirect = (req, res) => {
  // TODO: look up the code in your DB and redirect
  res.send("Yinkly redirect function is alive!");
};
